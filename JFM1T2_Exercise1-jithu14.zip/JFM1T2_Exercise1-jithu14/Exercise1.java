// Write a program to print your Name, Father's Name and Mailing Address in different lines

public class Exercise1 {
    
   public static void public static void main (String[] args) {
      
      system.out.println(name,fathername,mailingadress)
      
       
       
   } 



} 