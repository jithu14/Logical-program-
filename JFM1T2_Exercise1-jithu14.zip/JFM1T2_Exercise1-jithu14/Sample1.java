// Write a program to print your name

public class Sample1 {

	public static void main(String args[]) {
		
		system.out.println("HelloJithendra"); 
		
	}

}	
	

	//Print your name in Console
	public class sample2 {
		
		public static void main(sting args[]) {
			system.out.println(console) 
		}
	}
	}
}