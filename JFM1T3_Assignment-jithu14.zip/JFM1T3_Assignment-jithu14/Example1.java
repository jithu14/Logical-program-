import java.util.Scanner

class Example5{​

public static void main(String args[]){​

Scanner s=new Scanner(System.in);
System.out.println("Enter in totalmarks");
int amount=s.nextInt();

int a=0,b=0,c=0;
if(project%70==0){​
if(extrenal%20>=0){​
if(intenal%10>=0){

a=totalmarks/70;
a=project marks-(a*90);
System.out.println("90 enter in project marks, :"+a);

}​
if(totalmarks>=20){​

b=totalmarks/20;
b=extrenal marks-(b*70);
System.out.println("70 enter in extrenal marks :"+b);
}​
if(totalmarks>=10){​
c=intenal/10;
System.out.println("50 enter in intenal marks :"+c);
}​
}​
else{​
System.out.println("Please ente println fail subject along with score");
}​

}​
